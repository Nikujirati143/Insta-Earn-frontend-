export default function Dashboard() {
  return (
    <div className="bg-white text-black p-6 rounded-lg max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Earning Dashboard</h2>
      <p>Total Earnings: <span className="font-bold text-green-600">$0.00</span></p>
      <p>Referrals: <span className="font-bold text-blue-600">0</span></p>
    </div>
  );
}
