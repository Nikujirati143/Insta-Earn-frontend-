export default function Navbar() {
  return (
    <nav className="bg-white text-black p-4 flex justify-between shadow-md">
      <h1 className="font-bold text-xl">InstaEarn+</h1>
      <div className="space-x-4">
        <button className="px-4 py-2 bg-blue-500 text-white rounded-lg">Login</button>
        <button className="px-4 py-2 bg-purple-600 text-white rounded-lg">Signup</button>
      </div>
    </nav>
  );
}
