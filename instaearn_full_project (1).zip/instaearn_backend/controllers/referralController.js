const User = require('../models/User');

exports.getReferralData = async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        if (!user) return res.status(404).json({ message: "User not found" });

        res.json({
            earnings: user.earnings,
            referrals: user.referrals
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
